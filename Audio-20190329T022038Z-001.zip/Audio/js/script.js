//global variable to set the base zoom level, can be changed depending how much you wanna change the zoom.
let zoomLvl = 100;
let pic = document.getElementById("image1");
let images = ["AudioAssets/1.gif","AudioAssets/2.jpg","AudioAssets/3.jpg","AudioAssets/4.jpg","AudioAssets/5.jpg"];
//let audio = ["AudioAssets/1.wav","AudioAssets/2.wav","AudioAssets/3.wav","AudioAssets/4.wav"];
let curImage = 0

let track1 = document.getElementById('player');
let track2 = document.getElementById('player2');
let track3 = document.getElementById('player3');
let track4 = document.getElementById('player4');
let track5 = document.getElementById('player5');

let tracks = [track1, track2,track3,track4,track5];

//function that actually does the zoom thing\
let curWidth = 1280;
let curHeight = 720;
let originalHeight = 1280;
let originalWidth = 720;

function allTrackPause(){
    track1.pause();
    track1.currentTime = 0;
    track2.pause();
    track2.currentTime = 0;
    track3.pause();
    track3.currentTime = 0;
    track4.pause();
    track4.currentTime = 0;
    track5.pause();
    track5.currentTime = 0;
}


function zoomIn() {
    console.log(curWidth);
    console.log(curHeight);
    curWidth = curWidth-0.1*originalWidth;
    curHeight = curHeight- 0.1*originalHeight;
    tracks[curImage].volume = tracks[curImage].volume - 0.05;
    pic.style.width = (curWidth)+"px";
    pic.style.height = (curHeight)+"px";

    if(curHeight < 0.2*originalHeight && curWidth<0.2*originalWidth) {
        console.log("change now!, current image is" + curImage);
        curImage++;
        curImage = curImage%images.length;
        pic.src = images[curImage];
        pic.style.width = 1280;
        pic.style.height = 720;
        curWidth = 1280;
        curHeight = 720;
        originalWidth = 1280;
        originalHeight = 720;
        allTrackPause();
        tracks[curImage].volume = 1.0;
        tracks[curImage].play();
        
    }

} 



